import React from 'react'

function Content() {
  return (
    <div>
      Dashboard content
    </div>
  )
}

export default Content
